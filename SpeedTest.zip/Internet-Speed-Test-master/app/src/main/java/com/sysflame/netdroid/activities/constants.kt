package com.sysflame.netdroid.activities

object constants {
    const val APP_ID = "application-0-gsruj"
}