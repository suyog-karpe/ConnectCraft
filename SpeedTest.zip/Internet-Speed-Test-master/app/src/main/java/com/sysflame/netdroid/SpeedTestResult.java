package com.sysflame.netdroid;

import io.realm.RealmObject;

public class SpeedTestResult extends RealmObject {
    private long timestamp;
    private int ping;
    private double downloadSpeed;
    private double uploadSpeed;

    // Constructors, getters, setters, etc.
    // ...
}
