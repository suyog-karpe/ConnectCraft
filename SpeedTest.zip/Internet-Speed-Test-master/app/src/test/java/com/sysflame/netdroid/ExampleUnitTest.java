package com.sysflame.netdroid;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class ExampleUnitTest {
	@Test
	public void addition_isCorrect () {
		assertEquals (Double.doubleToLongBits (Math.log (Math.E)), Double.doubleToLongBits (1));
	}
}